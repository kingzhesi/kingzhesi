/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `schema_unused_indexes`(
`object_schema` int,
`object_name` int,
`index_name` int
);
