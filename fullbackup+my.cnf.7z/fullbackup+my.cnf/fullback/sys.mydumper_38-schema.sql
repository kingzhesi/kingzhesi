/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$user_summary_by_file_io`(
`user` int,
`ios` int,
`io_latency` int
);
