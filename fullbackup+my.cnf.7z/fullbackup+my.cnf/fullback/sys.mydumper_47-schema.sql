/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$waits_global_by_latency`(
`events` int,
`total` int,
`total_latency` int,
`avg_latency` int,
`max_latency` int
);
