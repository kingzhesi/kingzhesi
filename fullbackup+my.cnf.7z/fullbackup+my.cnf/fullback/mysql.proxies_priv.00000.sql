/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `proxies_priv` VALUES("localhost","root","","",1,"boot@connecting host","0000-00-00 00:00:00")
;
