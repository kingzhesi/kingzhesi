/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$memory_global_total`(
`total_allocated` int
);
