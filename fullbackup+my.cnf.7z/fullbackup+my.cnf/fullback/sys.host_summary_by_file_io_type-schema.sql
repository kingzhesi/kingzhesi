/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `host_summary_by_file_io_type`(
`host` int,
`event_name` int,
`total` int,
`total_latency` int,
`max_latency` int
);
