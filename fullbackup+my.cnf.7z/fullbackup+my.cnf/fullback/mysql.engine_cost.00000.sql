/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `engine_cost` VALUES("default",0,"io_block_read_cost",NULL,"2023-08-18 09:16:52",NULL)
,("default",0,"memory_block_read_cost",NULL,"2023-08-18 09:16:52",NULL)
;
