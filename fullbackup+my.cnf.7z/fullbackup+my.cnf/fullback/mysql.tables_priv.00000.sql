/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `tables_priv` VALUES("localhost","mysql","mysql.session","user","boot@connecting host","0000-00-00 00:00:00","Select","")
,("localhost","sys","mysql.sys","sys_config","root@localhost","2023-08-18 09:16:52","Select","")
;
