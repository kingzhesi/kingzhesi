/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `server_cost` VALUES("disk_temptable_create_cost",NULL,"2023-08-18 09:16:51",NULL)
,("disk_temptable_row_cost",NULL,"2023-08-18 09:16:51",NULL)
,("key_compare_cost",NULL,"2023-08-18 09:16:51",NULL)
,("memory_temptable_create_cost",NULL,"2023-08-18 09:16:51",NULL)
,("memory_temptable_row_cost",NULL,"2023-08-18 09:16:51",NULL)
,("row_evaluate_cost",NULL,"2023-08-18 09:16:51",NULL)
;
