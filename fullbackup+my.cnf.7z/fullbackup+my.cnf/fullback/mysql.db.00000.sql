/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `db` VALUES("localhost","performance_schema","mysql.session","Y","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N")
,("localhost","sys","mysql.sys","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","N","Y")
;
