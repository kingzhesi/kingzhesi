/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$latest_file_io`(
`thread` int,
`file` int,
`latency` int,
`operation` int,
`requested` int
);
