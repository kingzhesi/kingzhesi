/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `sys_config` VALUES("diagnostics.allow_i_s_tables","OFF","2023-08-18 09:16:52",NULL)
,("diagnostics.include_raw","OFF","2023-08-18 09:16:52",NULL)
,("ps_thread_trx_info.max_length","65535","2023-08-18 09:16:52",NULL)
,("statement_performance_analyzer.limit","100","2023-08-18 09:16:52",NULL)
,("statement_performance_analyzer.view",NULL,"2023-08-18 09:16:52",NULL)
,("statement_truncate_len","64","2023-08-18 09:16:52",NULL)
;
