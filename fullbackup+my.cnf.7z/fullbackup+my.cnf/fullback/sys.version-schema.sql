/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `version`(
`sys_version` int,
`mysql_version` int
);
