/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$ps_digest_avg_latency_distribution`(
`cnt` int,
`avg_us` int
);
