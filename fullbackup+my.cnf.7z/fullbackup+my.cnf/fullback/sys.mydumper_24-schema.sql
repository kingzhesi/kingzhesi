/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$schema_flattened_keys`(
`table_schema` int,
`table_name` int,
`index_name` int,
`non_unique` int,
`subpart_exists` int,
`index_columns` int
);
