/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$schema_tables_with_full_table_scans`(
`object_schema` int,
`object_name` int,
`rows_full_scanned` int,
`latency` int
);
