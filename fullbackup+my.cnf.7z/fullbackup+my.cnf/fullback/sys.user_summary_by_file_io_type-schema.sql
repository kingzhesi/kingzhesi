/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `user_summary_by_file_io_type`(
`user` int,
`event_name` int,
`total` int,
`latency` int,
`max_latency` int
);
