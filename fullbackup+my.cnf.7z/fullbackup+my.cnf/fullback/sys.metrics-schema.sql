/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `metrics`(
`Variable_name` int,
`Variable_value` int,
`Type` int,
`Enabled` int
);
