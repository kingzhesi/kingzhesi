/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `x$ps_digest_95th_percentile_by_avg_us`(
`avg_us` int,
`percentile` int
);
