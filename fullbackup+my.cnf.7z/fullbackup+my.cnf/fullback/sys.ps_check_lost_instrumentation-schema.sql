/*!40101 SET NAMES binary*/;
CREATE TABLE IF NOT EXISTS `ps_check_lost_instrumentation`(
`variable_name` int,
`variable_value` int
);
